# Sistema de Biblioteca

**Nombre del estudiante:** [ESCRIBA SU NOMBRE]  
**Número de cuenta:** [ESCRIBA SU NÚMERO DE CUENTA]  
**Proyecto:** Examen práctico del segundo parcial - Biblioteca

## Descripción

Aplicación Java con Maven que administra autores y libros mediante CRUD, interfaces DAO, implementaciones con `implements`, JDBC y SQLite. La relación es de uno a muchos: un autor puede tener varios libros y cada libro pertenece a un autor.

## Requisitos

- JDK 17 o superior.
- Apache Maven (si ejecuta desde terminal).
- NetBeans u otro IDE compatible con Maven.

## Ejecución en NetBeans

1. Descomprima el proyecto.
2. Abra NetBeans y seleccione **File > Open Project**.
3. Seleccione la carpeta `Biblioteca`.
4. Espere a que Maven descargue la dependencia SQLite JDBC.
5. Abra `src/main/java/hn/uth/poo/biblioteca/app/Main.java`.
6. Ejecute el archivo.

La aplicación crea `biblioteca.db` automáticamente en la carpeta de trabajo. La conexión activa `PRAGMA foreign_keys = ON`.

## Ejecución desde terminal

Desde la carpeta raíz del proyecto:

```bash
mvn clean compile
mvn exec:java
```

## Base de datos

El script `biblioteca.sql` contiene las tablas `autores` y `libros`, sus restricciones y la clave foránea. La aplicación también inicializa las tablas automáticamente al arrancar.

## Capas

- `modelo`: clases Autor y Libro.
- `excepciones`: DatosException y DatoInvalidoException.
- `dao`: conexión e interfaces AutorDAO y LibroDAO.
- `dao.impl`: implementaciones AutorDAOImpl y LibroDAOImpl.
- `servicio`: reglas de negocio y validaciones.
- `app`: menú de consola y unión de las capas.

## Reglas de negocio implementadas

- El nombre del autor es obligatorio.
- El título y el ISBN del libro son obligatorios.
- El ISBN no puede repetirse.
- El año, cuando se indica, debe estar entre 1450 y el año actual.
- El precio debe ser mayor o igual a cero.
- El autor del libro debe existir.
- No se puede eliminar un autor que tenga libros registrados.

## Evidencias

Guarde en la carpeta `evidencias` capturas reales de la ejecución que demuestren:

1. Crear, listar, buscar, actualizar y eliminar autores.
2. Crear, listar, buscar, actualizar y eliminar libros.
3. Listar libros por autor.
4. Rechazo de un ISBN repetido.
5. Rechazo al intentar eliminar un autor que tiene libros.

**Importante:** las capturas deben tomarse al ejecutar el programa. No se incluyen capturas simuladas.

## Historial de commits

Para que el repositorio muestre el avance, realice varios commits durante el trabajo, por ejemplo:

```bash
git add pom.xml .gitignore biblioteca.sql
git commit -m "Crear estructura Maven y script de base de datos"

git add src/main/java/hn/uth/poo/biblioteca/modelo
git commit -m "Agregar modelos Autor y Libro"

git add src/main/java/hn/uth/poo/biblioteca/dao
git commit -m "Crear interfaces DAO y conexión SQLite"

git add src/main/java/hn/uth/poo/biblioteca/dao/impl
git commit -m "Implementar operaciones JDBC de autores y libros"

git add src/main/java/hn/uth/poo/biblioteca/servicio
git commit -m "Agregar servicios y reglas de negocio"

git add src/main/java/hn/uth/poo/biblioteca/app README.md evidencias
git commit -m "Agregar menú, documentación y evidencias"
```

Los commits de ejemplo son instrucciones para realizar el historial en Git; no representan commits ya creados.
