package hn.uth.poo.biblioteca.servicio;

import hn.uth.poo.biblioteca.dao.AutorDAO;
import hn.uth.poo.biblioteca.dao.LibroDAO;
import hn.uth.poo.biblioteca.excepciones.DatoInvalidoException;
import hn.uth.poo.biblioteca.modelo.Libro;
import java.time.Year;
import java.util.List;
import java.util.Optional;

public class ServicioLibros {
    private final LibroDAO libroDAO;
    private final AutorDAO autorDAO;

    public ServicioLibros(LibroDAO libroDAO, AutorDAO autorDAO) {
        this.libroDAO = libroDAO;
        this.autorDAO = autorDAO;
    }

    public void crear(Libro libro) {
        validar(libro);
        validarIsbnUnico(libro.getIsbn(), 0);
        libroDAO.insertar(libro);
    }

    public List<Libro> listar() {
        return libroDAO.listar();
    }

    public List<Libro> listarPorAutor(int autorId) {
        validarAutorExiste(autorId);
        return libroDAO.listarPorAutor(autorId);
    }

    public Optional<Libro> buscarPorId(int id) {
        validarId(id);
        return libroDAO.buscarPorId(id);
    }

    public void actualizar(Libro libro) {
        validarId(libro.getId());
        if (libroDAO.buscarPorId(libro.getId()).isEmpty()) {
            throw new DatoInvalidoException("No existe un libro con ese ID.");
        }
        validar(libro);
        validarIsbnUnico(libro.getIsbn(), libro.getId());
        libroDAO.actualizar(libro);
    }

    public void eliminar(int id) {
        validarId(id);
        if (libroDAO.buscarPorId(id).isEmpty()) {
            throw new DatoInvalidoException("No existe un libro con ese ID.");
        }
        libroDAO.eliminar(id);
    }

    private void validar(Libro libro) {
        if (libro.getTitulo() == null || libro.getTitulo().trim().isEmpty()) {
            throw new DatoInvalidoException("El título del libro es obligatorio.");
        }
        if (libro.getIsbn() == null || libro.getIsbn().trim().isEmpty()) {
            throw new DatoInvalidoException("El ISBN es obligatorio.");
        }
        if (libro.getPrecio() < 0) {
            throw new DatoInvalidoException("El precio debe ser mayor o igual a cero.");
        }
        if (libro.getAnio() != null
                && (libro.getAnio() < 1450 || libro.getAnio() > Year.now().getValue())) {
            throw new DatoInvalidoException("El año debe estar entre 1450 y " + Year.now().getValue() + ".");
        }
        if (libro.getAutor() == null) {
            throw new DatoInvalidoException("Debe seleccionar un autor.");
        }
        validarAutorExiste(libro.getAutor().getId());
    }

    private void validarAutorExiste(int autorId) {
        if (autorId <= 0 || autorDAO.buscarPorId(autorId).isEmpty()) {
            throw new DatoInvalidoException("El autor indicado no existe.");
        }
    }

    private void validarIsbnUnico(String isbn, int idActual) {
        for (Libro existente : libroDAO.listar()) {
            if (existente.getIsbn().equalsIgnoreCase(isbn.trim())
                    && existente.getId() != idActual) {
                throw new DatoInvalidoException("El ISBN ya está registrado en otro libro.");
            }
        }
    }

    private void validarId(int id) {
        if (id <= 0) {
            throw new DatoInvalidoException("El ID debe ser mayor que cero.");
        }
    }
}
