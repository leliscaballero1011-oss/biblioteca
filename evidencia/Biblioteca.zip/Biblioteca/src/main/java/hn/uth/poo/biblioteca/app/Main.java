package hn.uth.poo.biblioteca.app;

import hn.uth.poo.biblioteca.dao.AutorDAO;
import hn.uth.poo.biblioteca.dao.Conexion;
import hn.uth.poo.biblioteca.dao.LibroDAO;
import hn.uth.poo.biblioteca.dao.impl.AutorDAOImpl;
import hn.uth.poo.biblioteca.dao.impl.LibroDAOImpl;
import hn.uth.poo.biblioteca.excepciones.DatosException;
import hn.uth.poo.biblioteca.modelo.Autor;
import hn.uth.poo.biblioteca.modelo.Libro;
import hn.uth.poo.biblioteca.servicio.ServicioAutores;
import hn.uth.poo.biblioteca.servicio.ServicioLibros;
import java.util.Optional;
import java.util.Scanner;

public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static ServicioAutores servicioAutores;
    private static ServicioLibros servicioLibros;

    public static void main(String[] args) {
        try {
            Conexion.inicializarBaseDatos();
            AutorDAO autorDAO = new AutorDAOImpl();
            LibroDAO libroDAO = new LibroDAOImpl();
            servicioAutores = new ServicioAutores(autorDAO, libroDAO);
            servicioLibros = new ServicioLibros(libroDAO, autorDAO);
            menuPrincipal();
        } catch (DatosException e) {
            System.out.println("Error de base de datos: " + e.getMessage());
        }
    }

    private static void menuPrincipal() {
        int opcion;
        do {
            System.out.println("\n===== SISTEMA DE BIBLIOTECA =====");
            System.out.println("1. Gestionar autores");
            System.out.println("2. Gestionar libros");
            System.out.println("0. Salir");
            opcion = leerEntero("Seleccione: ");
            switch (opcion) {
                case 1 -> menuAutores();
                case 2 -> menuLibros();
                case 0 -> System.out.println("Programa finalizado.");
                default -> System.out.println("Opción no válida.");
            }
        } while (opcion != 0);
    }

    private static void menuAutores() {
        int opcion;
        do {
            System.out.println("\n===== CRUD DE AUTORES =====");
            System.out.println("1. Crear autor");
            System.out.println("2. Listar autores");
            System.out.println("3. Buscar autor por ID");
            System.out.println("4. Actualizar autor");
            System.out.println("5. Eliminar autor");
            System.out.println("0. Volver");
            opcion = leerEntero("Seleccione: ");
            try {
                switch (opcion) {
                    case 1 -> crearAutor();
                    case 2 -> servicioAutores.listar().forEach(System.out::println);
                    case 3 -> buscarAutor();
                    case 4 -> actualizarAutor();
                    case 5 -> servicioAutores.eliminar(leerEntero("ID del autor: "));
                    case 0 -> { }
                    default -> System.out.println("Opción no válida.");
                }
            } catch (RuntimeException e) {
                mostrarError(e);
            }
        } while (opcion != 0);
    }

    private static void menuLibros() {
        int opcion;
        do {
            System.out.println("\n===== CRUD DE LIBROS =====");
            System.out.println("1. Crear libro");
            System.out.println("2. Listar libros");
            System.out.println("3. Buscar libro por ID");
            System.out.println("4. Actualizar libro");
            System.out.println("5. Eliminar libro");
            System.out.println("6. Listar libros de un autor");
            System.out.println("0. Volver");
            opcion = leerEntero("Seleccione: ");
            try {
                switch (opcion) {
                    case 1 -> crearLibro();
                    case 2 -> servicioLibros.listar().forEach(System.out::println);
                    case 3 -> buscarLibro();
                    case 4 -> actualizarLibro();
                    case 5 -> servicioLibros.eliminar(leerEntero("ID del libro: "));
                    case 6 -> servicioLibros.listarPorAutor(leerEntero("ID del autor: "))
                            .forEach(System.out::println);
                    case 0 -> { }
                    default -> System.out.println("Opción no válida.");
                }
            } catch (RuntimeException e) {
                mostrarError(e);
            }
        } while (opcion != 0);
    }

    private static void crearAutor() {
        Autor autor = leerDatosAutor();
        servicioAutores.crear(autor);
        System.out.println("Autor registrado. ID generado: " + autor.getId());
    }

    private static void actualizarAutor() {
        int id = leerEntero("ID del autor: ");
        Autor autor = leerDatosAutor();
        autor.setId(id);
        servicioAutores.actualizar(autor);
        System.out.println("Autor actualizado.");
    }

    private static Autor leerDatosAutor() {
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Nacionalidad: ");
        String nacionalidad = sc.nextLine();
        return new Autor(nombre, nacionalidad);
    }

    private static void buscarAutor() {
        Optional<Autor> autor = servicioAutores.buscarPorId(leerEntero("ID del autor: "));
        System.out.println(autor.map(Object::toString).orElse("Autor no encontrado."));
    }

    private static void crearLibro() {
        Libro libro = leerDatosLibro();
        servicioLibros.crear(libro);
        System.out.println("Libro registrado. ID generado: " + libro.getId());
    }

    private static void actualizarLibro() {
        int id = leerEntero("ID del libro: ");
        Libro libro = leerDatosLibro();
        libro.setId(id);
        servicioLibros.actualizar(libro);
        System.out.println("Libro actualizado.");
    }

    private static Libro leerDatosLibro() {
        System.out.print("ISBN: ");
        String isbn = sc.nextLine();
        System.out.print("Título: ");
        String titulo = sc.nextLine();
        int anioIngresado = leerEntero("Año (0 si no desea especificarlo): ");
        Integer anio = anioIngresado == 0 ? null : anioIngresado;
        double precio = leerDouble("Precio: ");
        int autorId = leerEntero("ID del autor: ");
        Autor autor = servicioAutores.buscarPorId(autorId)
                .orElseThrow(() -> new IllegalArgumentException("No existe un autor con ese ID."));
        return new Libro(isbn, titulo, anio, precio, autor);
    }

    private static void buscarLibro() {
        Optional<Libro> libro = servicioLibros.buscarPorId(leerEntero("ID del libro: "));
        System.out.println(libro.map(Object::toString).orElse("Libro no encontrado."));
    }

    private static int leerEntero(String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                int valor = Integer.parseInt(sc.nextLine().trim());
                return valor;
            } catch (NumberFormatException e) {
                System.out.println("Ingrese un número entero válido.");
            }
        }
    }

    private static double leerDouble(String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                return Double.parseDouble(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Ingrese un número válido.");
            }
        }
    }

    private static void mostrarError(RuntimeException e) {
        System.out.println("No se pudo completar la operación: " + e.getMessage());
    }
}
