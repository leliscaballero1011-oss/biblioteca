package hn.uth.poo.biblioteca.servicio;

import hn.uth.poo.biblioteca.dao.AutorDAO;
import hn.uth.poo.biblioteca.dao.LibroDAO;
import hn.uth.poo.biblioteca.excepciones.DatoInvalidoException;
import hn.uth.poo.biblioteca.modelo.Autor;
import java.util.List;
import java.util.Optional;

public class ServicioAutores {
    private final AutorDAO autorDAO;
    private final LibroDAO libroDAO;

    public ServicioAutores(AutorDAO autorDAO, LibroDAO libroDAO) {
        this.autorDAO = autorDAO;
        this.libroDAO = libroDAO;
    }

    public void crear(Autor autor) {
        validar(autor);
        autorDAO.insertar(autor);
    }

    public List<Autor> listar() {
        return autorDAO.listar();
    }

    public Optional<Autor> buscarPorId(int id) {
        validarId(id);
        return autorDAO.buscarPorId(id);
    }

    public void actualizar(Autor autor) {
        validarId(autor.getId());
        validar(autor);
        if (autorDAO.buscarPorId(autor.getId()).isEmpty()) {
            throw new DatoInvalidoException("No existe un autor con ese ID.");
        }
        autorDAO.actualizar(autor);
    }

    public void eliminar(int id) {
        validarId(id);
        if (autorDAO.buscarPorId(id).isEmpty()) {
            throw new DatoInvalidoException("No existe un autor con ese ID.");
        }
        if (libroDAO.listarPorAutor(id).size() > 0) {
            throw new DatoInvalidoException("No se puede eliminar: el autor tiene libros registrados.");
        }
        autorDAO.eliminar(id);
    }

    private void validar(Autor autor) {
        if (autor.getNombre() == null || autor.getNombre().trim().isEmpty()) {
            throw new DatoInvalidoException("El nombre del autor es obligatorio.");
        }
    }

    private void validarId(int id) {
        if (id <= 0) {
            throw new DatoInvalidoException("El ID debe ser mayor que cero.");
        }
    }
}
